package entidad;

import java.util.Date;

public class Empleado {
	private int codigo;
	private String nombre;
	private String apelli;
	private String direccion;
	private int codDistr;
	private String fecnac;
	private String fono;
	private String correo;
	private String estado;
	private String cell;
	private int codUs;
	private int codcar;
	
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getApelli() {
		return apelli;
	}
	public void setApelli(String apelli) {
		this.apelli = apelli;
	}
	public String getDireccion() {
		return direccion;
	}
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
	public int getCodDistr() {
		return codDistr;
	}
	public void setCodDistr(int codDistr) {
		this.codDistr = codDistr;
	}
	public String getFecnac() {
		return fecnac;
	}
	public void setFecnac(String fecnac) {
		this.fecnac = fecnac;
	}
	public String getFono() {
		return fono;
	}
	public void setFono(String fono) {
		this.fono = fono;
	}
	public String getCorreo() {
		return correo;
	}
	public void setCorreo(String correo) {
		this.correo = correo;
	}
	public String getEstado() {
		return estado;
	}
	public void setEstado(String estado) {
		this.estado = estado;
	}
	public String getCell() {
		return cell;
	}
	public void setCell(String cell) {
		this.cell = cell;
	}
	public int getCodUs() {
		return codUs;
	}
	public void setCodUs(int codUs) {
		this.codUs = codUs;
	}
	public int getCodcar() {
		return codcar;
	}
	public void setCodcar(int codcar) {
		this.codcar = codcar;
	}

	
}
