package entidad;

public class Proveedor {
	private Integer codigo;
	private String razon;
	private String ruc;
	private String direccion;
	private String telefono;
	private String Correo;
	private String pais;
	private Integer codcate;
	private String estado;
	private String nombrecate;
	public Integer getCodigo() {
		return codigo;
	}
	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}
	public String getRazon() {
		return razon;
	}
	public void setRazon(String razon) {
		this.razon = razon;
	}
	public String getRuc() {
		return ruc;
	}
	public void setRuc(String ruc) {
		this.ruc = ruc;
	}
	public String getDireccion() {
		return direccion;
	}
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
	public String getTelefono() {
		return telefono;
	}
	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}
	public String getCorreo() {
		return Correo;
	}
	public void setCorreo(String correo) {
		Correo = correo;
	}
	public String getPais() {
		return pais;
	}
	public void setPais(String pais) {
		this.pais = pais;
	}
	public Integer getCodcate() {
		return codcate;
	}
	public void setCodcate(Integer codcate) {
		this.codcate = codcate;
	}
	public String getEstado() {
		return estado;
	}
	public void setEstado(String estado) {
		this.estado = estado;
	}
	public String getNombrecate() {
		return nombrecate;
	}
	public void setNombrecate(String nombrecate) {
		this.nombrecate = nombrecate;
	}
	
	
	
	
}
