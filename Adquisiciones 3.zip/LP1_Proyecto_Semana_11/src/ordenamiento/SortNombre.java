package ordenamiento;

import java.util.Comparator;

import entidad.Bienes;
import entidad.Proveedor;

public class SortNombre implements Comparator<Bienes>{

	@Override
	public int compare(Bienes o1, Bienes o2) {
		// TODO Auto-generated method stub
		return  o1.getNombre().compareTo(o2.getNombre());
	}

}
