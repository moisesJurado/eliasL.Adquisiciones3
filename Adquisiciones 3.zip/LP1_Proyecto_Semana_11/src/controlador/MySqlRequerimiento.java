package controlador;

public class MySqlRequerimiento {
	/*CREATE TABLE `requerimiento` (
  `cod_requerimiento` int(11) NOT NULL,
  `cod_empleado` int(11) NOT NULL,
  `fec_requerimiento` date NOT NULL,
  `fec_entrega` date NOT NULL,
  `atencion_almacen_si_no` tinyint(4) NOT NULL,
  `est_requerimiento` varchar(15) NOT NULL DEFAULT 'ACTIVO',*/
	
	/*CREATE TABLE `detalle_requerimiento` (
  `cod_requerimiento` int(11) NOT NULL,
  `cod_bienes` int(11) NOT NULL,
  `cantidad_requerida` int(11) NOT NULL,
  `observaciones` varchar(500) NOT NULL,
  PRIMARY KEY (`cod_requerimiento`,`cod_bienes`),*/

}
