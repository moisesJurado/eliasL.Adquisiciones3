package util;

public class variables {
	public static String datos;
	public static int codigoUsuario;
}
